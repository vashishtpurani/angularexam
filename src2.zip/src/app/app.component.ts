import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'form';
  mobile: string;
  Name:string;
  namepattern ="^[a-zA-Z]{8,15}$";
  mobpattern = "^[0-1]{10}$";
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder){
    this.registerForm = this.formBuilder.group({
      title: ['', Validators.required],
      Name: ['', [Validators.required,Validators.pattern(this.namepattern)]],
      mobile: ['', [Validators.required, Validators.pattern(this.mobpattern)]],
      });
  }
get f(){
  return this.registerForm.controls;
}

hello(){
  this.submitted = true;
  if(this.registerForm.invalid){
  return;
  }
  alert('data fetch successfull\n\n' + JSON.stringify(this.registerForm.value, null, 4));
}
}



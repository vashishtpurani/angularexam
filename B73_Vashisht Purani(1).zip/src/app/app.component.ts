import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'exam';

  subject: any[] = [
    { Course_ID: 1,Course_Name:'BCA', Course_duration: 36, Course_fee: 2100},
    { Course_ID : 2,Course_Name:'MCA',Course_duration: 24,Course_fee: 3000},
    { Course_ID: 3,Course_Name:'MCOM',Course_duration: 4,Course_fee: 200000},
    { Course_ID: 4,Course_Name:'IMSCIT',Course_duration: 6,Course_fee: 27000},
    { Course_ID: 5,Course_Name:'MSCIT',Course_duration: 36,Course_fee: 34000}
  ];
}

/*
Write a C++ Program using Class and Object concept.
Function Type :- No Return Type No arguments
Perform the operations on array. Create three functions for
the following operations.

Name: Vashisht Purani
Roll.no : B73
Set: 10
Enrollment no:202100319010166
*/
#include<iostream>
using namespace std;
class abc{
    public:
    int a[5];
    void hello(){
        cout<<"Enter 5 numbers: \n";
        for(int i = 0;i<5;i++){
            cout<<"Enter number "<<(i+1)<<":";
            cin>>a[i];
        }
    }
    void hola(){
        cout<<"The value of array : \n";
        for(int i = 0;i<5;i++){
            cout<<a[i];
        }
        cout<<endl;
    }
    void sort(){
        cout<<"Sorting accending :";
        int temp = 0;
        for(int i = 0; i < 5; i++){
            for(int j = 1 + i; j < 5; j++){
                if(a[i] > a[j]){
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        for(int i = 0; i < 5; i++){
            cout<<a[i]<<"\t";
        }
        cout<<endl;
    }
};
int main(){

    abc t1;
    t1.hello();
    t1.hola();
    t1.sort();

}
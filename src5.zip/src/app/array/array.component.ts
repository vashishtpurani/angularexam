import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-array',
  templateUrl: './array.component.html',
  styleUrls: ['./array.component.css']
})
export class ArrayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
i=13;
arrayOfNum:any = [
  {num: 1},
  {num: 2},
  {num: 3},
  {num: 4},
  {num: 5},
  {num: 6},
  {num: 7},
  {num: 8},
  {num: 9},
  {num: 10}
]
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styling',
  templateUrl: './styling.component.html',
  styleUrls: ['./styling.component.css']
})
export class StylingComponent {

  getColor(country) { 
    switch (country) {
    case 'UK':
    return 'green';
    case 'USA':
    return 'blue';
    case 'IN':
    return 'red';}
    }

  people: any[] = [
    {name:'Anil Singh', age: 29, country: 'IN'},
    {name :'Alok Singh',age: 33,country: 'USA'},
    {name:'Raju',age: 28,country: 'UK'},
    { name:'Dilip Singh',age: 34,country: 'NP'},
    { name:'Param Trip',age: 32,country: 'USA'}
    ];
    
}


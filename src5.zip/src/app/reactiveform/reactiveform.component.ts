import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormControl } from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent implements OnInit {
  title:string="Reactive Form!"

  constructor() { }

  ngOnInit(): void {
  }

  pattern1: string="^[a-zA-Z].{2,15}$";
  empform = new FormGroup({
    empid: new FormControl('',[Validators.required,Validators.pattern('^[A-Za-z0-9]{4}$')]),
    empname: new FormControl('',[Validators.required,Validators.pattern(this.pattern1)]),
    salary: new FormControl('',[Validators.required,Validators.pattern('^[0-9]{1,9}$')]),
  })
  empUser()
  {
    console.warn(this.empform.value)
  }
  get empid()
  {
    return this.empform.get('empid')
  }
  get empname()
  {
    return this.empform.get('empname')  
  }
  get salary()
  {
    return this.empform.get('salary')
  }
}


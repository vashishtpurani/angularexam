import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tempdriven',
  templateUrl: './tempdriven.component.html',
  styleUrls: ['./tempdriven.component.css']
})
export class TempdrivenComponent{

  getValue(values:any)
  {
    console.warn(values)
    alert('Submitted Successfully')
  }
}

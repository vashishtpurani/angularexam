import { Component } from '@angular/core';
  
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  
{
  title = 'Gls University'
  a=['gfg1', 'gfg2', 'gfg3', 'gfg4']

  getColor(country) { 
    switch (country) {
    case 'UK':
    return 'green';
    case 'USA':
    return 'blue';
    case 'IN':
    return 'red';}
    };
    
  users = [
    { firstName: 'Frank', lastName: 'Murphy', email: 'frank.murphy@test.com', role: 'User' },
    { firstName: 'Vic', lastName: 'Reynolds', email: 'vic.reynolds@test.com', role: 'Admin' },
    { firstName: 'Gina', lastName: 'Jabowski', email: 'gina.jabowski@test.com', role: 'Admin' },
    { firstName: 'Jessi', lastName: 'Glaser', email: 'jessi.glaser@test.com', role: 'User' },
    { firstName: 'Jay', lastName: 'Bilzerian', email: 'jay.bilzerian@test.com', role: 'User' }
];

abc = [
  {name: 'Douglas Pace'},
  {name: 'Mcleod Mueller'},
  {name: 'Day Meyers'},
  {name: 'Aguirre Ellis'},
  {name: 'Cook Tyson' }
  ];
  
  people: any[] = [
    {name:'Anil Singh', age: 29, country: 'IN'},
    {name :'Alok Singh',age: 33,country: 'USA'},
    {name:'Raju',age: 28,country: 'UK'},
    { name:'Dilip Singh',age: 34,country: 'NP'},
    { name:'Param Trip',age: 32,country: 'USA'}
    ];

*/
 peopleByCountry: any[] = [
    {'country': 'UK',
    'address':'sss',
          'people': [
        {"name": "Douglas  Pace"},
        {"name": "Mcleod  Mueller"},
      ]
    },
    {
      'country': 'US',
      'address':'aa',
      'people': [
        {
          "name": "Day  Meyers"
        },
        {
          "name": "Aguirre  Ellis"
        },
        {
          "name": "Cook  Tyson"
        }
      ]
    }
  ];
    employees: any[] = 
    [ { id: 1, name: 'Ram', salary: 5000 },
       { id: 2, name: 'John', salary: 1000 }, 
      { id: 3, name: 'Franc', salary: 3000 },
       { id: 4, name: 'Andrew', salary: 8000 } ]; 
}

